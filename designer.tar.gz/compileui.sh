pyuic5 Lyrical.ui -o Lyrical.py
