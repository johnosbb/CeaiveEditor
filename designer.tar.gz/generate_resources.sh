pyrcc5 resources.qrc -o resources.py
